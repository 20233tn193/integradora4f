package com.company.books.backend.api_casilleros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiCasillerosApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiCasillerosApplication.class, args);
    }

}
