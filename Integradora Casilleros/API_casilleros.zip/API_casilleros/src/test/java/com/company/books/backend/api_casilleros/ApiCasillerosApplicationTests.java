package com.company.books.backend.api_casilleros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCasillerosApplicationTests {

    @Test
    void contextLoads() {
    }

}
